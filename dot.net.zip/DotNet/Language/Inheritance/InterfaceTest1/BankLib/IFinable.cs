namespace Met.Banking;

public interface IFinable 
{
    bool Withdraw(double fine);
}